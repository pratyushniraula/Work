# Devlog - 2025-04-02 05:41
Just setting up everything right now so that it is easy to just commit and do everything tonight.

Learned a lot from the last project. More work the week before the due date and a language switch to pythong. Prof said something about mac compilations not working as well for pthreads and stuff so I'm going to use python. Also learned that C is a mission to understand, debug, and work on. I do not want to experience what I did last week again. 

Looking over documentation now.

running python3 main.py is such a strain, I created a script to do it. But make sure when grading that execution permissions have been given to the file

# Devlog - 2025-04-12 19:23
Been extremely busy with both work and school so I'm glad he pushed this project over to the end of the weekend. Let's get to coding. I understand the requirements now after reading it more throughout the week with the intention of working on it but not getting through it.

Worked on creating the semaphores after reading up more on it. Also introduced the idea of using a queue to handle the queue.
Which might be genius, but no other data structure would work as perfectly as this, and python has it built in so why not.
I'm still in the process of planning out the actual logic but I think I have a general idea (hopefully)

# Devlog - 2025-04-13 02:45
Semaphores done, thinking maybe to have individual threads. One for teller one for customer. Instead of one big function being a thread handling all of that, that way there is a seperation in everything that is done and allows for there to be a direct flow that works. 

Just implemented basic threads. This is insanely easy compared to C. Like that was one line of prep, no need for all those
individual arguments inside of threads, all of it is handled for you.

Trying to make the customer actually wait and enter the bank now. After handling that I will be able to handle the communication between the teller and the customer.

Created some of the main logic flow with how I think it should work. It will basically call tellers first, then call customers. 
Also it's getting a little out of hand for how everything is going between interactions between teller and banker. I have to
figure out how that interaction between threads is going to take place. I'm going to sleep on that one and try it again in the morning.


# Devlog - 2025-04-13 11:26
Back after sleeping good. Now let's see where I left off.
Threading is not working for when I'm trying to create multiple threads, I don't know what to do so let's see.
Threads sorta work now, but they are not stopping for the customer thread. Let's see the issue, idk why because I fixed the timer issue but there is nothing there as of right now to cause this.
I added a semaphore for printing. If everything is printing at once it's going to be a jumble of information


# Devlog - 2025-04-13 14:05
Back to wondering why the threads are not working properly. They seem to be stuck, or at least one of the customer threads is stuck and I don't understand why.

I think I got the main flow down. Customers and tellers will interact with each other, but the main will just initialize and deal with everything. The queue will deal with all the customers waiting in line and tellers will address customers individually.
I started working on teller threads but they seem to need a little bit more time and going back and forth from the docs, sample run and the code I have here.


# Devlog - 2025-04-13 16:05
Python is actually insanely simple compared to C, I kinda forget at times but this feels like cheating and time is flying by slow with a lot more work done with less headaches. In C I had so much to set up and so much to review and so much to randomly debug throughout the code,e but this is insane.

Semaphores did not work for some reason, I've been looking over stack overflow and trying to see why my code is not working with them. I'm going to just continue without them for now and see where I go from there.

Speaking of semaphores what if I were to use them to delay the interaction within tellers and customers and have them at a set pace. There is no way implemented to control them right now. That will require some heavy duty thinking.

What if I were to name each customer not by threads but by a number in the for loop that makes.

decided to use a lock rather than a semaphore for the code. I don't know how semaphores did not work but a lock on printing worked. I still have 3 other semaphores in the code right now so that shouldn't be a problem.

Completing this code in around 4 hours from now might be a struggle but I'm down for a challenge. Customer thread function is almost done, teller thread is still being worked on but there is a lot to do as of right now. I have interactions writted down in a piece of paper but implementing it is harder than I originally thought.

Teller being worked on right now and I have a plan. Teller is going by pretty decently but I have not tested it at all. The problem is that I cannot test it until customer is completely done which will take a while. As of right now I have a couple hours before I have to submit the project. Let's see if I can meet the deadline in time. I have been working on this for over 9 hours nonstop. I have no clue if it's going to work and it is a gamble but stack overflow and google will be my heroes. Unfortunately I'm assuming that AI is not allowed for this type of work. 

Teller should be done but now I have to make the right interactions between teller and customer.

# Devlog - 2025-04-13 21:05

Took a quick 5 minute break and decided that I should push changes as to show actual progress rather than finally pushing one solid piece of working code compared to nimble and brittle state that I had it in before. 

Currently working on synchronizing everything for both teller and customer. Customer will have to put itself inside of the queue.

I thought about using events, but I kinda realize that I do need to use semaphores based on what I have seen in the docs. Which is a problem since I use a lock for printing, but I think that I should be fine if I just attempt to fix it before submitting the program. 

I created an object for customer so that I don't have to deal with the nonsense in communication between threads, instead they will just communicate to one another using this object. The object contains all the things the teller and the customer have to do to complete the interaction. 

I don't know if we can possibly use events actually instead of semaphores, but I don't want to lose points on a technicality so I'll find a way for it to work.

An hour left and I'm starting to panick. I have done all the synchronization between the teller and the customer (I think), I mapped it all in my head and on a piece of paper, but I don't know why it's not working on the terminal...
This is insane, I gotta grind until this is due, (1 hour 8 minutes).


I should have been a business major...

I think everything is working properly. I'm adding comments now to solidify everything and making sure everything is readable, commenting might take a while but I think I can do it in time, it might take me like 20 minutes at least so I gotta do it fast. Time is running out for all of this.

AHHHHH EVERYTHING DOES WORK I AM ALMOST DONE. COMMENTING IS DONE FOR THE MOST PART. THIS WAS SO STRESSFUL.

jeez that took a lot of work, a lot of headache but python is king and python is so much easier to do than any other programming language, best believe that I am using python for any and all remaining projects in this class. 

I was not able to update devlog that much towards the end but that was because time was running out. As of this message I only have 10 minutes to submit so I am going to make final preparations and submit this in a timely manner. 
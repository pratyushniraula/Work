import sys
import os
import csv
import struct

# Constants
BLOCK_SIZE = 512
MAGIC = b"4348PRJ3"
MAGIC_PAD = MAGIC.ljust(8, b"\x00")
MIN_DEGREE = 10
MAX_KEYS = 2 * MIN_DEGREE - 1
MAX_CHILDREN = MAX_KEYS + 1
HEADER_FORMAT = ">8sQQ"  # magic, root_id, next_block_id
NODE_HEADER_FORMAT = ">QQQ"  # block_id, parent, num_keys
KEY_FORMAT = ">Q"  # 8-byte unsigned
PTR_FORMAT = ">Q"

class BTreeNode:
    def __init__(self, block_id, parent=0):
        self.block_id = block_id
        self.parent = parent
        self.keys = []
        self.values = []
        self.children = []  # block IDs

    # serialize the node to bytes
    # format: block_id, parent, num_keys, keys[], values[], children[]
    # keys and values are 8-byte unsigned integers
    def serialize(self):
        # header
        data = struct.pack(NODE_HEADER_FORMAT, self.block_id, self.parent, len(self.keys))
        # keys
        for i in range(MAX_KEYS):
            val = self.keys[i] if i < len(self.keys) else 0
            data += struct.pack(KEY_FORMAT, val)
        # values
        for i in range(MAX_KEYS):
            val = self.values[i] if i < len(self.values) else 0
            data += struct.pack(KEY_FORMAT, val)
        # children
        for i in range(MAX_CHILDREN):
            val = self.children[i] if i < len(self.children) else 0
            data += struct.pack(PTR_FORMAT, val)
        # pad
        data += b"\x00" * (BLOCK_SIZE - len(data))
        return data

    # deserialize the node from bytes
    # format: block_id, parent, num_keys, keys[], values[], children[]
    # keys and values are 8-byte unsigned integers
    @classmethod
    def deserialize(cls, data):
        header_size = struct.calcsize(NODE_HEADER_FORMAT)
        block_id, parent, num_keys = struct.unpack(NODE_HEADER_FORMAT, data[:header_size])
        node = cls(block_id, parent)
        offset = header_size
        # keys
        for _ in range(MAX_KEYS):
            (k,) = struct.unpack(KEY_FORMAT, data[offset:offset+8])
            if len(node.keys) < num_keys:
                node.keys.append(k)
            offset += 8
        # values
        for _ in range(MAX_KEYS):
            (v,) = struct.unpack(KEY_FORMAT, data[offset:offset+8])
            if len(node.values) < num_keys:
                node.values.append(v)
            offset += 8
        # children
        for _ in range(MAX_CHILDREN):
            (c,) = struct.unpack(PTR_FORMAT, data[offset:offset+8])
            if len(node.children) < num_keys + 1:
                node.children.append(c)
            offset += 8
        return node
################################################################################################
class BTree:
    # constructor
    def __init__(self, filename):
        self.filename = filename
        if not os.path.exists(filename):
            raise FileNotFoundError(f"Index file {filename} not found.")
        self.fp = open(filename, 'r+b')
        self._read_header()

    # create a new B-tree index file
    # format: magic, root_id, next_block_id
    @staticmethod
    def create(filename):
        if os.path.exists(filename):
            print(f"Error: file {filename} already exists.")
            sys.exit(1)
        with open(filename, 'w+b') as f:
            # write header
            root_id = 0
            next_block = 1
            header = struct.pack(HEADER_FORMAT, MAGIC_PAD, root_id, next_block)
            f.write(header)
            f.write(b"\x00" * (BLOCK_SIZE - len(header)))
        print(f"Created index file {filename}.")


    #########################################################################################################
    #read write header and node stuff
    # read the header of the index file
    def _read_header(self):
        # read the header
        self.fp.seek(0)
        header = self.fp.read(BLOCK_SIZE)
        magic, self.root_id, self.next_block = struct.unpack(HEADER_FORMAT, header[:struct.calcsize(HEADER_FORMAT)])
        # if magic != MAGIC_PAD then the file is not a valid index file
        if magic.rstrip(b"\x00") != MAGIC:
            print("Error: invalid index file.")
            sys.exit(1)

    # write the header of the index file
    def _write_header(self):
        self.fp.seek(0)
        # pack the header in format: magic, root_id, next_block
        # magic is already padded
        header = struct.pack(HEADER_FORMAT, MAGIC_PAD, self.root_id, self.next_block)
        self.fp.write(header)
        # rest unchanged

    # read the node from the index file
    def _read_node(self, block_id):
        self.fp.seek(block_id * BLOCK_SIZE)
        # read the block and return the deserialized node
        data = self.fp.read(BLOCK_SIZE)
        return BTreeNode.deserialize(data)

    # write the node to the index file
    def _write_node(self, node):
        self.fp.seek(node.block_id * BLOCK_SIZE)
        self.fp.write(node.serialize())

    #########################################################################################################
    #search stuff
    #search for a key in the B-tree
    # format: key, value
    def search(self, key):
        if self.root_id == 0:
            print("Error: tree is empty.")
            return
        return self._search_recursive(self.root_id, key)

    # recursive search function for the B-tree
    def _search_recursive(self, block_id, key):
        node = self._read_node(block_id)
        # find position
        i = 0
        # find the first key greater than or equal to key
        while i < len(node.keys) and key > node.keys[i]:
            i += 1
        # if key is found then return the value
        if i < len(node.keys) and key == node.keys[i]:
            print(f"Found: {key} -> {node.values[i]}")
            return
        # if leaf node then key is not found then return error
        if len(node.children) == 0 or node.children[i] == 0:
            print("Error: key not found.")
            return
        # recursive search in the child node
        return self._search_recursive(node.children[i], key)
    
    #########################################################################################################
    #insert stuff
    # split the child of a node when it is full
    # format: parent, length
    def _split_child(self, parent, length):
        t = MIN_DEGREE
        child = self._read_node(parent.children[length])
        new_child = BTreeNode(self.next_block)
        self.next_block += 1
        new_child.parent = parent.block_id
        # move keys/values
        new_child.keys = child.keys[t:]
        new_child.values = child.values[t:]
        # move children
        if child.children:
            new_child.children = child.children[t:]
        # reduce child
        child.keys = child.keys[:t-1]
        child.values = child.values[:t-1]
        child.children = child.children[:t]
        # insert in parent
        parent.keys.insert(length, child.keys[t-1])
        parent.values.insert(length, child.values[t-1])
        parent.children.insert(length+1, new_child.block_id)
        # write nodes
        self._write_node(child)
        self._write_node(new_child)
        self._write_node(parent)

    # insert a key-value pair in a non-full node
    # format: node, key, value
    def _insert_nonfull(self, node, key, value):
        if len(node.children) == 0 or node.children[0] == 0:
            # leaf
            length = len(node.keys) - 1
            node.keys.append(0)
            node.values.append(0)
            # find position to insert
            # find the first key greater than or equal to key
            while length >= 0 and key < node.keys[length]:
                node.keys[length+1] = node.keys[length]
                node.values[length+1] = node.values[length]
                length -= 1
            # write the new key-value pair
            node.keys[length+1] = key
            node.values[length+1] = value
            self._write_node(node)
            print(f"Inserted {key}:{value} in leaf {node.block_id}.")
        else:
            # non-leaf
            # find the first key greater than or equal to key
            length = len(node.keys) - 1
            while length >= 0 and key < node.keys[length]:
                length -= 1
            length += 1
            # if child is full then split it
            child = self._read_node(node.children[length])
            if len(child.keys) == MAX_KEYS:
                self._split_child(node, length)
                if key > node.keys[length]:
                    length += 1
                child = self._read_node(node.children[length])
            # insert in child
            self._insert_nonfull(child, key, value)

    #main insert function
    def insert(self, key, value):
        # if empty tree
        if self.root_id == 0:
            # create root
            root = BTreeNode(self.next_block)
            self.root_id = root.block_id
            self.next_block += 1
            root.keys = [key]
            root.values = [value]
            root.children = []
            self._write_header()
            self._write_node(root)
            print(f"Inserted {key}:{value} as root.")
            return
        root = self._read_node(self.root_id)
        if len(root.keys) == MAX_KEYS:
            # split if full
            new_root = BTreeNode(self.next_block)
            self.next_block += 1
            new_root.children = [self.root_id]
            root.parent = new_root.block_id
            self._write_node(root)
            self.root_id = new_root.block_id
            self._write_header()
            self._split_child(new_root, 0)
            self._insert_nonfull(new_root, key, value)
            print("Splitting root")
        else:
            # insert in non-full root
            self._insert_nonfull(root, key, value)
    ##########################################################################################################
    #printing stuff
    def print_all(self):
        if self.root_id == 0:
            return
        # call the recursive function to print the B-tree
        self._print_recursive(self.root_id)

    # recursive function to print the B-tree
    # format: key, value
    def _print_recursive(self, block_id):
        # read the node
        node = self._read_node(block_id)
        # print the keys and values recursively
        for i, k in enumerate(node.keys):
            if node.children and node.children[i] != 0:
                # if the child is not empty then call the recursive function
                self._print_recursive(node.children[i])
            # print the key and value to kernel
            print(f"{k},{node.values[i]}")
        # print the last child
        if node.children and node.children[-1] != 0:
            # if the last child is not empty then call the recursive function
            self._print_recursive(node.children[-1])

    ##############################################################################################################
    #extraction stuff
    def extract(self, outfile):
        # call the recursive function to extract the B-tree
        with open(outfile, 'w', newline='') as csvfile:
            writer = csv.writer(csvfile)
            self._extract_recursive(self.root_id, writer)
        print(f"Extracted to {outfile}.")

    def _extract_recursive(self, block_id, writer):
        # if the block_id is 0 then return
        if block_id == 0:
            return
        # read the node
        node = self._read_node(block_id)
        # write the keys and values recursively
        # format: key, value
        for i, k in enumerate(node.keys):
            if node.children and node.children[i] != 0:
                self._extract_recursive(node.children[i], writer)
            writer.writerow([k, node.values[i]])
        if node.children and node.children[-1] != 0:
            self._extract_recursive(node.children[-1], writer)
    ##########################################################################################################
    #csv stuff

    # load data from a CSV file into the B-tree
    # format: key, value
    def load_csv(self, csvfile):
        # check if the file exists
        if not os.path.exists(csvfile):
            print(f"Error: CSV file {csvfile} not found.")
            sys.exit(1)
        # open the CSV file and read the data
        with open(csvfile, newline='') as f:
            reader = csv.reader(f)
            for row in reader:
                # map and call the insert function
                k, v = map(int, row)
                self.insert(k, v)

    ###############################################################################################################
    # close the index file
    def close(self):
        self.fp.close()


################################################################################################

def usage():
    print("Usage: project3 <command> [<args>]")
    print("Commands:")
    print("create <file>\tCreate a new B-tree index file")
    print("insert <file> <key> <value>\tInsert a key-value pair into the B-tree")
    print("search <file> <key>\tSearch for a key in the B-tree")
    print("load <file>\tLoad data from a CSV file into the B-tree")
    print("print <file>\tPrint all keys in the B-tree")
    print("extract <file>\tExtract keys from the B-tree to a CSV file")
    sys.exit(1)

# main is self explanatory and is just a long embedded if else statement
def main():
    if len(sys.argv) < 2:
        usage()
    cmd = sys.argv[1].lower()
    if cmd == "create":
        if len(sys.argv) != 3:
            print("Usage: project3 create <file>")
            sys.exit(1)
        BTree.create(sys.argv[2])
    else:
        btreeInstance = BTree(sys.argv[2])
        if cmd == "insert":
            k = int(sys.argv[3])
            v = int(sys.argv[4])
            btreeInstance.insert(k, v)
        elif cmd == "search":
            k = int(sys.argv[3])
            btreeInstance.search(k)
        elif cmd == "load":
            btreeInstance.load_csv(sys.argv[3])
        elif cmd == "print":
            btreeInstance.print_all()
        elif cmd == "extract":
            btreeInstance.extract(sys.argv[3])
        else:
            print(f"Unknown command")
        btreeInstance.close()


if __name__ == "__main__":
    main()
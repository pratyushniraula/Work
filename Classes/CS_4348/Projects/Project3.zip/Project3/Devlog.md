# Devlog - 2025-05-10 22:17
Starting this a little late but will need to speedrun this faster than even the last project.
Luckily this is in python so it should not be too terrible but I need to look over the documentation one more time in order to fully grasp what I have to do. I've been extremely busy with finals and everything so hopefully I can complete this in time.

# Devlog - 2025-05-11 12:46
I have read the documents and now I'm planning on how to code everything on paper. I need to do this fast and efficiently if I am to finish this in time. I think I remember going over at least some of this in class but I don't remember to what extent. I made the flow of main that I think would work in this situation. It is basically just going to see if it is create, insert, search, load, print, extract. Now from having the main set up in a way where I only have to implement the functions I should be good to go through each of them and find a way to implement them all.



# Devlog - 2025-05-11 (sometime after the last commit [seperating devlog entries by commits since I'm doing this all in 1 day])
Since we are using a btree not as its normal data structure format only being stored in memory, I have to create a class btree itself. My goal for this now is to just implement the functions. 

A slight change in plans, if I make the overall Btree class handle all the operations it should make everything easier to do and handle. I think I might do that in order to make it a little more coherent and synchronized.

I also have to keep track of the constants so I put them how they are based on the document. I searched up how to make everything have the same endian values and how to even evaluate the magic number stuff too. Honestly a lot of the constants made no sense in how I could implement it so I just had to search them all up on how to do each of them and add it here.

Create is done but I do not know if I can even test until after implementing some of the other features first. So I'm just going to keep on implementing functions until I feel like I am ready to run the program and test. Which means heavy amounts of debugging.

Implementing insert right now but the main problem is that I might need another class for each node of the Btree. I don't see any other way to go about it right now, I need a way to serialize and deserialize from in memory node to binary and binary to in memory node. 

Oh my god this sucks, having a project due like this in the middle of finals week is insane, I actually hate this. I don't think I can finish in time but I kinda have no choice but to. I think serialize and deserialize work and I don't think I need to do anything else for the btreenode class but that was a lot of pain and a lot of stack overflow to implement. Unfortunately we cannot use AI, but that would be so clutch right now. 

Project due in Mother's day is crazy, I can't even spend time with my mom without this class pounding us with never ending assignments and projects. I still have to complete the hws due by tomorrow. An extension for the project would be hugely appreciated. 

I forgot to save the devlog before commiting but I had this here too:

BTreeNode not working...

I'm redoing the entire thing.

I think it works now. I created different for loops for key, child and values for packing and unpacking in both seralizing and deserializing instead of having one for loop do all the work. Overall I don't know how it works compared to the one before because the logic flow is still the same but I'll take it. I think it should be good.

Search actually might be easier to implement, it's a tree so I can just do it recursively. The logic I think is good enough for now but I need to test it. That will be a later problem when tying everything together

Going back to insert.



# Devlog - 2025-05-11 21:27
Long commit but I kinda have no choice but to focus more on the actual implementation of the project than the commits. 

Insert is almost done. I Only have a couple hours left so I might have to submit this a little late. As of right now I have everything that I need to do planned out and I know how to implement it but I do need to look up specific syntax in order to implement it. I have a bunch of subfunctions to just keep the other functions alive. I think I implemented those fine but the problem is that I need to be able to use those and have them work properly for all the parts to interweave as I want them to. This project is a little unorthodox so I'm trying a new way of programming but I think based off of how I wrote my pseudocode that this should be good enough. 

Accounting for the cases of splitting the btree is a huge task too, this is absurd. But I think I should have it under wraps for now, if all goes well I should be able to complete this all with relative ease if my preplanning actually works. Subfunctions are done for the most part and now I just have to implement the other parts of the actual program. Insert was actually crazy to implement, but based on my logic it works. We'll see how it works in practicality but I know that theoretically it works.


# Devlog - 2025-05-11 02:12
Kinda decided not to sleep and instead just work on this... I just need to finish printing, extracting, and the csv stuff, and the script. I think I could finish before 12 if I just hammer away at it right now. 

So far my thinking is to use enumerate and do an in order traversal using the print. Only way to traverse a tree is from recursion, which should be simple enough, but this is a btree, so I have to see if it still is the same. If a node has a child and node.children is not 0 it recursively calls the print function. Iterating over the keys it will do an in order traversal from left to parent to right.

Print feature is done.

# Devlog - 2025-05-11 09:50
Nvm it was wrong it didn't work correctly. I started working on extract. I only have a couple hours left before I only get 10 points off. I might try to speedrun but this will take hella time.

Extract will call extract recursive to do an in order traversal to have the key value pairs to be extracted into the csv, Not that complicated.

I think I made the same mistake using the key like on printing, I need to change that back. Load is the only thing I have left n ow


# Devlog - 2025-05-11 10:50

extracting done now I need to do loading. I have been working on this so long that I have lost all sense of time and now there is a doomclock ticking where I must complete this all in time or lose all the progress I have made for my grade so far. All loading is going to do is check for file existence, open file, iterates over the rows of keys and values, converts to integers, inserts them into the btree. Easy enough right? Maybe...

Okay it kinda was that easy. I should've started this a little earlier but I think this is fine. I have to make the script now to run it but other than that it should be good. I don't know if the script is a requirement or not, but I guess I still have to do it. I might not and just test it myself. Either way it's debugging time now from all the code I've written.


# Devlog - 2025-05-11 11:24
There wasn't much issue debugging, there were some lines that needed changing but overall I think the project is complete. The script is basic but it works and everything is in order. I should be good to submit. I added comments beforehand so it should be good now